﻿
public interface IControl_ProductItemList
{
    string Nombre_producto
    {
        get;
        set;
    }
    string Marca_producto
    {
        get;
        set;
    }
    string Precio_producto
    {
        get;
        set;
    }
    bool Dispobible
    {
        get;
        set;
    }
    string Descripcion_producto
    {
        get;
        set;
    }
}
