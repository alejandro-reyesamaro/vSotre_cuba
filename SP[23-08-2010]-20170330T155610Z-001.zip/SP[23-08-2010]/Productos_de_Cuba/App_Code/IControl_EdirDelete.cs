﻿using System.Web.UI.WebControls;
using System.Web.UI;

public interface IControl_EditDelete
{
    int ID_Item
    {
        get;
        set;
    }      
}
